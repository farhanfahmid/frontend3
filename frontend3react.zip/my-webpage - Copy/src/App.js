import React from 'react';
import Header from './components/Header';

import Section1 from './components/Section1';
import PlayerOfTheWeek from './components/Section2';
import DynamicSection from './components/DynamicSection';
import GameStatistics from './components/Section3';
import PlayerSpotlights from './components/Section4';


const App = () => {
  return (
    <div>
      <Header />
      <Section1 />
      <PlayerOfTheWeek />
      <GameStatistics />
      <PlayerSpotlights />
      <DynamicSection />
    </div>
  );
};





export default App;
