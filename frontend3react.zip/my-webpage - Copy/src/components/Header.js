import React from 'react';

const Header = () => {
  return (
    <header className='header-style'>
      <h1>RANK N STATS</h1>
    </header>
  );
};

export default Header;
