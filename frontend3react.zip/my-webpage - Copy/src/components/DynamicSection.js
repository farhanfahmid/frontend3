import React, { useEffect, useState } from 'react';

const DynamicSection = () => {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    // Fetch leaderboard data from the API
    fetch('https://64743e827de100807b1a84ab.mockapi.io/api/v1/leaderboard/users')
      .then((response) => response.json())
      .then((data) => {
        setPlayers(data);
      })
      .catch((error) => console.error(error));
  }, []);

  return (
    <section className='player-rankings-table'>
      <h2>Player Rankings</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Country</th>
            <th>Score</th>
            <th>Avatar</th>
          </tr>
        </thead>
        <tbody>
          {players.length > 0 ? (
            players.map((player) => (
              <tr key={player.id}>
                <td>{player.id}</td>
                <td>{player.name}</td>
                <td>{player.country}</td>
                <td>{player.score}</td>
                <td>
                  <img src={player.photo} alt="Avatar" style={{ width: '50px', height: '50px' }} />
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5">Loading leaderboard data...</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default DynamicSection;
