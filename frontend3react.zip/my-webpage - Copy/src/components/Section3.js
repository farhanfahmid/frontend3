import '../styles/App.css';

import React, { useEffect, useState } from 'react';
import Chart from 'react-google-charts';

const GameStatistics = () => {
  const [playersCount, setPlayersCount] = useState(0);
  const [averageScore, setAverageScore] = useState(0);

  useEffect(() => {
    // Fetch the leaderboard data to calculate game statistics
    fetch('https://64743e827de100807b1a84ab.mockapi.io/api/v1/leaderboard/users')
      .then((response) => response.json())
      .then((data) => {
        setPlayersCount(data.length);
        const totalScore = data.reduce((sum, player) => sum + player.score, 0);
        setAverageScore(totalScore / data.length);
      })
      .catch((error) => console.error(error));
  }, []);

  return (
    <section>
      <h2>Game Statistics</h2>
      <p>Total Players: {playersCount}</p>
      <p>Average Score: {averageScore.toFixed(2)}</p>
      <Chart
        width={'100%'}
        height={'300px'}
        chartType="BarChart"
        loader={<div>Loading Chart...</div>}
        data={[
          ['Statistic', 'Value'],
          ['Total Players', playersCount],
          ['Average Score', averageScore],
        ]}
        options={{
          chartArea: { width: '50%' },
          hAxis: { title: 'Value', minValue: 0 },
          vAxis: { title: 'Statistic' },
        }}
      />
    </section>
  );
};

export default GameStatistics;

