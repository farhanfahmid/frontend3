import '../styles/App.css';

import React, { useEffect, useState } from 'react';

const PlayerOfTheWeek = () => {
  const [playerOfTheWeek, setPlayerOfTheWeek] = useState(null);

  useEffect(() => {
    // Fetch the top player of the week from the leaderboard data
    fetch('https://64743e827de100807b1a84ab.mockapi.io/api/v1/leaderboard/users')
      .then((response) => response.json())
      .then((data) => {
        // Sort the data to get the player with the highest score
        const sortedData = data.sort((a, b) => b.score - a.score);
        const topPlayer = sortedData[0];
        setPlayerOfTheWeek(topPlayer);
      })
      .catch((error) => console.error(error));
  }, []);

  return (
    <section className='player-of-week'>
      <h2 className='player-of-week-h2'>Player of the Week</h2>
      {playerOfTheWeek ? (
        <div>
          <h3>{playerOfTheWeek.name}</h3>
          <p className='player-of-week-p'>Score: {playerOfTheWeek.score}</p>
          <img src={playerOfTheWeek.photo} alt="Player Avatar" />
          <p>Congratulations to the Player of the Week! Keep up the good work!</p>
          <p>Can you beat their score? Join the game and compete now!</p>
        </div>
      ) : (
        <p>Loading player of the week...</p>
      )}
    </section>
  );
};

export default PlayerOfTheWeek;

