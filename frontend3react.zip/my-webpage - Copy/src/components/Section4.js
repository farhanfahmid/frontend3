import '../styles/App.css';


import React, { useEffect, useState } from 'react';
//import './PlayerSpotlights.css'; // Import the CSS file for styling

const PlayerSpotlights = () => {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    // Fetch a few notable players from the leaderboard data
    fetch('https://64743e827de100807b1a84ab.mockapi.io/api/v1/leaderboard/users')
      .then((response) => response.json())
      .then((data) => {
        // Select a subset of players for the spotlights
        const spotlights = data.slice(1, 4); // Adjust the range as per your preference
        setPlayers(spotlights);
      })
      .catch((error) => console.error(error));
  }, []);

  return (
    <section className="player-spotlights">
      <h2>Player Spotlights</h2>
      {players.length > 0 ? (
        players.map((player) => (
          <div key={player.id} className="player-spotlight">
            <img src={player.photo} alt="Player Avatar" />
            <h4 className="player-name">{player.name}</h4>
            <p className="player-score">Score: {player.score}</p>
          </div>
        ))
      ) : (
        <p>Loading player spotlights...</p>
      )}
    </section>
  );
};

export default PlayerSpotlights;


