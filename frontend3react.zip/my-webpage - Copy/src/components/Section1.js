import '../styles/App.css';


import React, { useEffect, useState } from 'react';

const Section1 = () => {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    // Fetch leaderboard data from the API
    fetch('https://64743e827de100807b1a84ab.mockapi.io/api/v1/leaderboard/users')
      .then((response) => response.json())
      .then((data) => {
        setPlayers(data);
      })
      .catch((error) => console.error(error));
  }, []);

  // Get the top 5 players based on score
  const topPlayers = players.sort((a, b) => b.score - a.score).slice(0, 5);

  return (
    <section className='top-countries-style'>
      <h2 className='top-countries-text-style'>Top Countries</h2>
      <ul>
        {topPlayers.map((player) => (
          <li key={player.id}>
            <strong>{player.country}</strong> - {player.name} ({player.score})
          </li>
        ))}
      </ul>
    </section>
  );
};

export default Section1;

